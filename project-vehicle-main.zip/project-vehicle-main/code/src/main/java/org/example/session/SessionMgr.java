package org.example.session;

public class SessionMgr {
    public SessionMgr() {
        System.out.println("This is a dummy session");
    }
}
