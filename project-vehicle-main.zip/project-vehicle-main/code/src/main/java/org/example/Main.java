package org.example;

import org.example.session.SessionMgr;

public class Main {
    static void main() {
        SessionMgr sessionMgr = new SessionMgr();
    }
}
