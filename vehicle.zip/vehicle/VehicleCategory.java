package org.example.vehicle;

public enum VehicleCategory {
    ECONOMY,
    STANDARD,
    PREMIUM,
    LUXURY
}
