package org.example.vehicle;

public enum VehicleStatus {
    AVAILABLE,
    RENTED,
    UNDER_MAINTENANCE,
    RESERVED
}
